=============================================================================
-  Visual Studio Code extension for Retro Assembler                         -
=============================================================================

You can download it directly from Visual Studio Code's extension marketplace
by searching for "retro assembler", or by visiting this page:

https://marketplace.visualstudio.com/items?itemName=EngineDesigns.retroassembler

Check out the Readme file of the extension itself inside VS Code about
how to set it up.

Updates to the extension will be automatically installed by VS Code.
