=============================================================================
-  Retro Assembler V2021.1                   Release Date: January 1, 2021  -
=============================================================================

Crafted by Peter Tihanyi with 8-Bit Love

(C) 2017-2021 Engine Designs in West Virginia, USA


Website: https://enginedesigns.net/retroassembler


Requires .NET 5.0 -- https://dotnet.microsoft.com/download 

Runs on Windows, macOS and Linux, on X86, X64 and ARM architectures.
